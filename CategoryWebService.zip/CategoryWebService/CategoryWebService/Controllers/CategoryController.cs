﻿using CategoryWebService.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace CategoryWebService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        NorthwindContext db = new NorthwindContext();


        [HttpGet("KategoriListesi")]
        public IEnumerable<Category> GetCategories()
        {

            return db.Categories.ToList();
        }

        [HttpGet("Getir/{id:int}")]
        public Category GetKategoriByID(int id)
        {
            return db.Categories.Find(id);
        }

        [HttpPost("Ekle")]
        public bool AddCategory([FromBody] Category c)
        {
            db.Categories.Add(c);
            return db.SaveChanges() > 0 ? true : false;
        }
        [HttpPut("Guncelle")]

        public bool UpdateCategory([FromBody] Category c)
        {
            db.Categories.Update(c);
            return db.SaveChanges() > 0 ? true : false;
        }
        [HttpDelete("Remove/{id:int}")]

        public bool DeleteCategory(int id)
        {
            db.Categories.Remove(db.Categories.Find(id));

            return db.SaveChanges() > 0 ? true : false;
        }

    }
}
