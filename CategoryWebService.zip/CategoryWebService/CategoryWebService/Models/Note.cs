﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CategoryWebService.Models
{
    public partial class Note
    {
        public int Id { get; set; }
        public int Score { get; set; }
        public int LessonId { get; set; }
        public int StudentId { get; set; }
        public DateTime? CreateDate { get; set; }
        public DateTime? UpdateDate { get; set; }

        public virtual Lesson Lesson { get; set; }
        public virtual Student Student { get; set; }
    }
}
