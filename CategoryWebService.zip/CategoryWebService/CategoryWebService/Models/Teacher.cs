﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CategoryWebService.Models
{
    public partial class Teacher
    {
        public int Id { get; set; }
        public string TeacherName { get; set; }
        public string TeacherSurname { get; set; }
        public int LessonId { get; set; }
        public DateTime? CreateDate { get; set; }
        public DateTime? UpdateDate { get; set; }

        public virtual Lesson Lesson { get; set; }
    }
}
