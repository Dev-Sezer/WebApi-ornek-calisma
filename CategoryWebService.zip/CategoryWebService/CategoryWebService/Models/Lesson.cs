﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CategoryWebService.Models
{
    public partial class Lesson
    {
        public Lesson()
        {
            Notes = new HashSet<Note>();
            Teachers = new HashSet<Teacher>();
        }

        public int Id { get; set; }
        public string LessonName { get; set; }
        public DateTime? CreateDate { get; set; }
        public DateTime? UpdateDate { get; set; }

        public virtual ICollection<Note> Notes { get; set; }
        public virtual ICollection<Teacher> Teachers { get; set; }
    }
}
