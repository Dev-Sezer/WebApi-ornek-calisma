﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CategoryWebService.Models
{
    public partial class Student
    {
        public Student()
        {
            Notes = new HashSet<Note>();
        }

        public int Id { get; set; }
        public string StudentName { get; set; }
        public string StudentSurname { get; set; }
        public string Gender { get; set; }
        public DateTime? CreateDate { get; set; }
        public DateTime? UpdateDate { get; set; }

        public virtual ICollection<Note> Notes { get; set; }
    }
}
